﻿Public NotInheritable Class frmSplash

    Private Sub frmSplash_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        WriteLog("Splash Form : Initializing CRM...")

        Try
            Version.Text = System.String.Format(Version.Text, My.Application.Info.Version.Major, My.Application.Info.Version.Minor)

            Copyright.Text = My.Application.Info.Copyright

        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message)
            WriteLog("Login Form : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
        End Try

    End Sub

End Class

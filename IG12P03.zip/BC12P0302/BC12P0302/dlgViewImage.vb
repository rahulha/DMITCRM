﻿Imports System.Windows.Forms

Public Class dlgViewImage

    Public Sub New(ByVal Title As String, ByVal Image As Image)
        InitializeComponent()
        Me.Text = Title
        Me.pbFingerPreview.Image = Image
    End Sub

    Private Sub dlgViewImage_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        'Me.Close()
    End Sub
End Class

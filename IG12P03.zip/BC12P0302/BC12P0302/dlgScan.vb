﻿Imports System.Windows.Forms
Imports Ionic.Zip
Imports System.Threading
Imports System.IO
Imports ScanAPIHelper
Imports System.Runtime.InteropServices

Public Class dlgScan

    Dim currentHand As HandSide
    Dim currentFinger As Finger
    Dim currentFSide As FingerSide

    Dim ImageList As Hashtable

    Dim fPath As String
    Dim tempPath As String
    Dim CustomerCode As String
    Dim CustomerName As String

    Dim EditModeModifiedList As List(Of String)
    Dim isEditMode As Boolean = False

    Public Sub New(ByVal CustomerCode As String, ByVal CustomerName As String)

        InitializeComponent()

        Me.CustomerCode = CustomerCode
        Me.CustomerName = CustomerName

        Try
            fPath = Application.StartupPath & "\CustData\" & CustomerCode & "_" & CustomerName
            tempPath = System.IO.Path.GetTempPath & CustomerCode & "_" & CustomerName

            currentHand = HandSide.Left
            currentFinger = Finger.Thumb
            currentFSide = FingerSide.Center

            ImageList = New Hashtable
            EditModeModifiedList = New List(Of String)

            If IO.File.Exists(fPath & ".szf") Then
                WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Mode: Existing")

                isEditMode = True

                'extract folder & show images
                If IO.Directory.Exists(tempPath) Then
                    WriteLog("Scan Form: Action : Delete:" + CustomerCode + "; Mode: TempFolder")
                    IO.Directory.Delete(tempPath, True)
                End If

                Try

                    Using zip As ZipFile = ZipFile.Read(fPath & ".szf")
                        WriteLog("Scan Form: Action : Unzip:" + CustomerCode + "; to TempFolder")

                        zip.Encryption = EncryptionAlgorithm.WinZipAes256
                        zip.Password = GetSettings("EncryptKey").ToString
                        zip.ExtractAll(tempPath, Ionic.Zip.ExtractExistingFileAction.OverwriteSilently)
                        zip.Dispose()
                    End Using

                    Dim files As String() = Directory.GetFiles(tempPath, "*.jpg")

                    For Each Str As String In files
                        WriteLog("Scan Form: Action : Add to List:" + CustomerCode + "; File: " + Str)

                        Try

                            Dim name As String() = Str.Substring(tempPath.Length + 1).Replace(".jpg", "").Split("_")

                            If name(0).Equals("LEFT", StringComparison.InvariantCultureIgnoreCase) Then
                                currentHand = HandSide.Left
                            Else
                                currentHand = HandSide.Right
                            End If

                            Select Case name(1)
                                Case "Thumb" : currentFinger = Finger.Thumb
                                Case "Index" : currentFinger = Finger.Index
                                Case "Middle" : currentFinger = Finger.Middle
                                Case "Ring" : currentFinger = Finger.Ring
                                Case "Little" : currentFinger = Finger.Little
                            End Select

                            Select Case name(2)
                                Case "Left" : currentFSide = FingerSide.Left
                                Case "Center" : currentFSide = FingerSide.Center
                                Case "Right" : currentFSide = FingerSide.Right
                            End Select

                            Dim s1 As New FileStream(Str, FileMode.Open, FileAccess.Read)

                            Dim b As New Bitmap(s1)
                            s1.Close()
                            s1.Dispose()

                            AddIteminList(currentHand, currentFinger, currentFSide, b)

                            pbFingerPreview.Image = b

                        Catch ex As Exception
                            WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data: Adding Image from File to List(" + Str + ")")

                        End Try

                    Next

                    currentHand = HandSide.Right
                    currentFinger = Finger.Little
                    currentFSide = FingerSide.Right
                    btnCapture.Enabled = False

                Catch ex As Exception
                    MessageBox.Show(String.Format("There's been a problem extracting that zip file.  {0}", ex.Message), "Error Extracting", MessageBoxButtons.OK, MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button1)

                    WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data: Extracting Zip File (" + fPath + ")")
                End Try

                lblCurrent.Text = "Current: NA"
            Else
                'create folder & allow to add
                WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Mode: New")
                IO.Directory.CreateDirectory(tempPath)

                lblCurrent.Text = "Current: " & currentHand.ToString() & " Hand, " & currentFinger.ToString() & " Finger, " & currentFSide.ToString() & " Side"
            End If

            lblPrev.Text = "Previous: NA"

            Button1.Enabled = False
            Button2.Enabled = False

        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message)
            WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)

        End Try
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Me.Cursor = Cursors.WaitCursor
        Me.SuspendLayout()

        If bwScanner.IsBusy Then
            bwScanner.CancelAsync()
        End If

        Try
            If lvScanList.Items.Count <> 30 Then
                MsgBox("You have not scanned all fingers yet,So cannot save the file.Please scan all remaining " & (30 - ImageList.Count).ToString(), MsgBoxStyle.Critical, "Upgrade Finger print")
                WriteLog("Scan Form: Action : Error: Less than 30 Finger scaned")
                Exit Sub
            End If

            If isEditMode Then
                WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Saving Existing")

                For Each Key As String In EditModeModifiedList

                    Dim Str As String = tempPath & "\" & Key & ".jpg"

                    Dim img As Bitmap = ImageList(Key)
                    Try
                        img.Save(Str, System.Drawing.Imaging.ImageFormat.Jpeg)
                        WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; File Saved: " + Key)
                    Catch ex As Exception
                        WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; File Not Saved: " + Key)
                        WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
                    End Try
                Next
            Else
                WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Saving New")

                For i As Integer = 0 To ImageList.Count - 1

                    Dim Str As String = tempPath & "\" & ImageList1.Images.Keys(i) & ".jpg"

                    Dim img As Bitmap = ImageList(ImageList1.Images.Keys(i))
                    Try
                        img.Save(Str, System.Drawing.Imaging.ImageFormat.Jpeg)
                        WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; File Save:" + ImageList1.Images.Keys(i))

                    Catch ex As Exception
                        WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; File Not Saved: " + ImageList1.Images.Keys(i))
                        WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
                    End Try
                Next

            End If

            WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Images Saved")

            ImageList.Clear()
            ImageList = Nothing

            EditModeModifiedList.Clear()
            EditModeModifiedList = Nothing

            WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Creating Zip...")

            Dim DataTable As DataTable = general.GetDataTable(("SELECT * FROM tblCustomer WHERE CustCode = '" & CustomerCode & "'"))
            DataTable.TableName = "CustomerProfile"

            If (DataTable.Rows.Count > 0) Then
                Dim xdfPath As String = CustomerCode + "_" + CustomerName + ".xdf"
                xdfPath = tempPath & "\" & xdfPath

                If File.Exists(xdfPath) Then
                    File.Delete(xdfPath)
                End If

                DataTable.WriteXml(xdfPath, XmlWriteMode.IgnoreSchema)
            End If

            Using zip1 As ZipFile = New ZipFile

                zip1.AddDirectory(tempPath)

                For Each z As ZipEntry In zip1.Entries
                    z.Encryption = EncryptionAlgorithm.WinZipAes256
                    z.Password = GetSettings("EncryptKey").ToString
                    'My.Settings.MasterKey
                Next

                If IO.File.Exists(fPath & ".szf") Then
                    IO.File.Delete(fPath & ".szf")
                End If

                If Not Directory.Exists(Application.StartupPath & "\CustData") Then
                    Directory.CreateDirectory(Application.StartupPath & "\CustData")
                End If

                zip1.Save(fPath & ".szf")
                zip1.Dispose()

                IO.Directory.Delete(tempPath, True)
                WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Zip Created")

            End Using

            'general.WriteData("UPDATE tblCustomer SET isScanned=1 WHERE CustCode = '" + CustomerCode + "'")

            'If Not isEditMode Then
            '    general.WriteData("UPDATE tblSettings SET UsedLot=UsedLot+1")
            'End If

        Catch ex1 As Exception
            MessageBox.Show(String.Format("Exception while zipping: {0}", ex1.Message))
            WriteLog("Scan Form: Error : " + ex1.Message + "; Source:" + ex1.Source + "; StackTrace:" + ex1.StackTrace + "; HelpLink:" + ex1.HelpLink)
        End Try

        Me.Cursor = Cursors.Default
        Me.ResumeLayout()

        WriteLog("Scan Form: Close: Ok Button")
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        WriteLog("Scan Form: Close: Cancel Button")
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub CaptureScan(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCapture.Click
        Try
            Me.Cursor = Cursors.WaitCursor
            Me.Enabled = False
            Me.SuspendLayout()

            If AddIteminList(currentHand, currentFinger, currentFSide, hBitmap.Clone) Then

                lblPrev.Text = "Previous: " & currentHand.ToString() & " Hand, " & currentFinger.ToString() & " Finger, " & currentFSide.ToString() & " Side"

                If Me.FingerMode Then

                    Try
                        Dim key As String = currentHand.ToString + "_" + currentFinger.ToString + "_" + currentFSide.ToString
                        If EditModeModifiedList.IndexOf(key) = -1 Then
                            EditModeModifiedList.Add(key)
                        End If

                    Catch ex As Exception
                        WriteLog("Scan Form: Action : Customer:" + CustomerCode + "; Edit Mode File Add: " + currentHand.ToString + "_" + currentFinger.ToString + "_" + currentFSide.ToString)
                        WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
                    End Try

                    currentHand = continueHand
                    currentFinger = continueFinger
                    currentFSide = continueFSide
                    FingerMode = False

                    'lblPrev.Text = "Previous: NA"
                    'lblCurrent.Text = "Current: NA"

                    btnCapture.Enabled = False
                    lvScanList.Enabled = True

                    Button1.Enabled = False
                    Button2.Enabled = False
                    Button2.Text = "Edit"
                End If

                If currentFSide < 2 Then
                    currentFSide += 1

                Else
                    currentFSide = FingerSide.Center

                    If currentFinger < 4 Then
                        currentFinger += 1

                    Else
                        currentFinger = Finger.Thumb

                        If currentHand < 1 Then
                            currentHand += 1

                        Else
                            btnCapture.Enabled = False
                        End If

                    End If

                End If

                lblCurrent.Text = "Current: " & currentHand.ToString() & " Hand, " & currentFinger.ToString() & " Finger, " & currentFSide.ToString() & " Side"
            End If

        Catch ex As Exception
            MsgBox("Please place your finger on scanner first!", MsgBoxStyle.Critical, "Scanning error")

            WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
        Finally
            Me.Cursor = Cursors.Default
            Me.ResumeLayout()
            Me.Enabled = True

        End Try
    End Sub

    Dim FingerMode As Boolean
    Dim continueHand As HandSide
    Dim continueFinger As Finger
    Dim continueFSide As FingerSide

#Region "Scanner Handler"

    Private hBitmap As Bitmap
    Public m_hDevice As Device
    Public m_Frame As Byte()

    Private Function AddIteminList(ByVal HandSide As HandSide, ByVal Finger As Finger, ByVal FingerSide As FingerSide, ByVal Image As Bitmap) As Boolean

        Try

            If ImageList.Contains(HandSide.ToString() & "_" & Finger.ToString() & "_" & FingerSide.ToString()) Then

                ImageList1.Images.RemoveByKey(HandSide.ToString() & "_" & Finger.ToString() & "_" & FingerSide.ToString())
                ImageList1.Images.Add(HandSide.ToString() & "_" & Finger.ToString() & "_" & FingerSide.ToString(), Image)

                ImageList(HandSide.ToString() & "_" & Finger.ToString() & "_" & FingerSide.ToString()) = Image

            Else

                ImageList1.Images.Add(HandSide.ToString() & "_" & Finger.ToString() & "_" & FingerSide.ToString(), Image)

                ImageList.Add(HandSide.ToString() & "_" & Finger.ToString() & "_" & FingerSide.ToString(), Image)

                Dim itm As New ListViewItem(FingerSide.ToString(), HandSide.ToString() & "_" & Finger.ToString() & "_" & FingerSide.ToString(), Me.lvScanList.Groups(HandSide.ToString() & Finger.ToString()))
                itm.ToolTipText = FingerSide.ToString() & " of " & Finger.ToString() & " Finger, " & HandSide.ToString() & " Hand." & Environment.NewLine & " Select and double click to update image."

                lvScanList.Items.Add(itm)

                itm.EnsureVisible()

            End If

            Return True
        Catch ex As Exception
            MsgBox("Please place your finger on scanner first!", MsgBoxStyle.Critical, "Scanning error")
            WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data: Adding Image ListView (" & currentHand.ToString() & "_" & currentFinger.ToString() & "_" & currentFSide.ToString() & " Side")
            Return False
        End Try
    End Function

    Private Sub bwScanner_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles bwScanner.DoWork
        Me.m_hDevice = Nothing
        Dim num As Integer = 0
Restart:
        Do
            Try
                Me.m_hDevice = New Device
                Me.m_hDevice.Open()

                num = 5
            Catch ex As ScanAPIException
                WriteLog("Scan Form: Error : " + ex.Message + "; Data: Device opening failed, Attempt: " + num.ToString)

                If num = 5 Then
                    MsgBox("Device starting failed. Please check your device. If this error continue to occur please contact Administrator for further assistance.")
                    WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + " Data: Device starting failed permanantly.")

                    Exit Sub
                End If
            End Try
            num += 1
        Loop While (num <= 5)

        WriteLog("Scan Form: Action : Device Srated, Process Initiated.")
        'Try
        Do While Not Me.bwScanner.CancellationPending

            Dim num2 As Integer
            Dim lastErrorCode As Integer = 0
            Dim flag As Boolean = True

Label_00A6:

            Do While (Not Me.m_hDevice.IsFingerPresent AndAlso Not Me.bwScanner.CancellationPending)

                If (lastErrorCode <> Me.m_hDevice.LastErrorCode) Then
                    lastErrorCode = Me.m_hDevice.LastErrorCode

                    Select Case lastErrorCode
                        Case 0, &H10D2, &H20000001, &H20000002
                            GoTo Label_009E
                        Case &H20000004, &H20000005
                            num2 = 1
                            Exit Select
                        Case Else
                            num2 = 0
                            Exit Select
                    End Select

                    If (num2 <> 0) Then
                        MsgBox("The device does not support the requested feature", MsgBoxStyle.Critical, "Finger Scan")

                        WriteLog("Scan Form: Action: Error : The device does not support the requested feature")
                    Else
                        MsgBox(String.Format("Unknown error #{0}", lastErrorCode), MsgBoxStyle.Critical, "Finger Scan")

                        WriteLog("Scan Form: Action: Error : Unknown error " + lastErrorCode)
                    End If
                End If

Label_009E:
                Thread.Sleep(0)
            Loop
            If Me.bwScanner.CancellationPending Then
                Return
            End If

            Try
                Me.m_Frame = Me.m_hDevice.GetFrame

                flag = False
            Catch exception As ScanAPIException
                lastErrorCode = Me.m_hDevice.LastErrorCode

                Select Case lastErrorCode
                    Case &H20000001, 0, &H10D2
                        Exit Select
                    Case &H20000002
                        MsgBox("Fake finger was detected", MsgBoxStyle.Critical, "Finger Scan")
                        Exit Select
                    Case &H20000004, &H20000005
                        num2 = 1
                        GoTo Label_015C
                    Case Else
                        num2 = 0
                        GoTo Label_015C
                End Select

                GoTo Label_0192
Label_015C:
                If (num2 <> 0) Then
                    MsgBox("The device does not support the requested feature", MsgBoxStyle.Critical, "Finger Scan")

                    WriteLog("Scan Form: Action: Error : The device does not support the requested feature")
                Else
                    MsgBox(String.Format("Unknown error #{0}", lastErrorCode), MsgBoxStyle.Critical, "Finger Scan")

                    WriteLog("Scan Form: Action: Error : Unknown error " + lastErrorCode)
                End If

            End Try

Label_0192:
            If flag Then
                GoTo Label_00A6
            End If

            If ((Not Me.m_Frame Is Nothing) AndAlso (Me.m_Frame.Length <> 0)) Then

                Try
                    Me.hBitmap = CreateBitmap(Me.pbFingerPreview.CreateGraphics.GetHdc, Me.m_hDevice.ImageSize, Me.m_Frame)

                    Me.hBitmap.RotateFlip(RotateFlipType.Rotate180FlipX)

                    Me.pbFingerPreview.Image = Me.hBitmap.Clone
                Catch ex As Exception

                    m_Frame = Nothing
                    WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + " Data: Craeting Image and display in ImageBox")

                    If (Not Me.m_hDevice Is Nothing) AndAlso Not bwScanner.CancellationPending Then
                        m_hDevice.Close()
                        Me.m_hDevice.Dispose()
                        Me.m_hDevice = Nothing

                        GoTo Restart
                    End If

                End Try
            End If
        Loop
    End Sub

    Private Sub dlgScan_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If bwScanner.IsBusy Then
            bwScanner.CancelAsync()
        End If

        If IO.Directory.Exists(tempPath) Then
            IO.Directory.Delete(tempPath, True)
        End If
        WriteLog("Scan Form: Close : Ok Button")

    End Sub

    Private Sub dlgScan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        WriteLog("Scan Form: Action : Initializing Scaning Process...")

        bwScanner.RunWorkerAsync()

    End Sub

    Private Sub bwScanner_RunWorkerCompleted(ByVal sender As System.Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles bwScanner.RunWorkerCompleted
        Try
            WriteLog("Scan Form: Action: Stopping Scaning Process...")

            If (Not Me.m_hDevice Is Nothing) Then
                m_hDevice.Close()
                Me.m_hDevice.Dispose()
                Me.m_hDevice = Nothing
                WriteLog("Scan Form: Action: Scaning Process Stopped ")

            End If

        Catch ex As Exception

        End Try
    End Sub

#End Region

    Private Sub lvScanList_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvScanList.SelectedIndexChanged
        Try
            If lvScanList.SelectedIndices.Count > 0 Then
                Button1.Enabled = True
                Button2.Enabled = True
            Else
                Button1.Enabled = False
                Button2.Enabled = False
            End If
        Catch ex As Exception
            Button1.Enabled = False
            Button2.Enabled = False
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If lvScanList.SelectedItems.Count > 0 Then

            Try
                Dim index As Integer = lvScanList.SelectedIndices(0)

                Dim itm As ListViewItem = lvScanList.Items(index)
                Dim imgKey As String() = itm.ImageKey.Split("_")

                Dim tmpHand As HandSide
                Dim tmpFinger As Finger
                Dim tmpFSide As FingerSide

                If imgKey(0).Equals("LEFT", StringComparison.InvariantCultureIgnoreCase) Then
                    tmpHand = HandSide.Left
                Else
                    tmpHand = HandSide.Right
                End If

                Select Case imgKey(1)
                    Case "Thumb" : tmpFinger = Finger.Thumb
                    Case "Index" : tmpFinger = Finger.Index
                    Case "Middle" : tmpFinger = Finger.Middle
                    Case "Ring" : tmpFinger = Finger.Ring
                    Case "Little" : tmpFinger = Finger.Little
                End Select

                Select Case imgKey(2)
                    Case "Left" : tmpFSide = FingerSide.Left
                    Case "Center" : tmpFSide = FingerSide.Center
                    Case "Right" : tmpFSide = FingerSide.Right
                End Select

                Dim f As New dlgViewImage("Current: " & tmpHand.ToString() & " Hand, " & tmpFinger.ToString() & " Finger, " & tmpFSide.ToString() & " Side", ImageList(itm.ImageKey))
                If f.ShowDialog = DialogResult.OK Then
                    f.Dispose()
                    f = Nothing
                End If

            Catch ex As Exception
                MsgBox("Error ocurred: " & ex.Message)

                WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data: Double click ListView (" & currentHand.ToString() & "_" & currentFinger.ToString() & "_" & currentFSide.ToString() & " Side")
                lvScanList.Enabled = True
            End Try
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        If Button2.Text.Equals("Cancel") Then

            Try
                Me.Cursor = Cursors.WaitCursor
                Me.Enabled = False
                Me.SuspendLayout()

                lblPrev.Text = "Previous: " & currentHand.ToString() & " Hand, " & currentFinger.ToString() & " Finger, " & currentFSide.ToString() & " Side"

                If Me.FingerMode Then

                    currentHand = continueHand
                    currentFinger = continueFinger
                    currentFSide = continueFSide
                    FingerMode = False

                    btnCapture.Enabled = False
                    lvScanList.Enabled = True
                End If

                If currentFSide < 2 Then
                    currentFSide += 1

                Else
                    currentFSide = FingerSide.Center

                    If currentFinger < 4 Then
                        currentFinger += 1

                    Else
                        currentFinger = Finger.Thumb

                        If currentHand < 1 Then
                            currentHand += 1
                        Else
                            btnCapture.Enabled = False

                        End If

                    End If

                End If

                lblCurrent.Text = "Current: " & currentHand.ToString() & " Hand, " & currentFinger.ToString() & " Finger, " & currentFSide.ToString() & " Side"

            Catch ex As Exception

                WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
            Finally
                Button2.Text = "Edit"
                Button2.Enabled = False
                Button1.Enabled = False

                Me.Cursor = Cursors.Default
                Me.ResumeLayout()
                Me.Enabled = True

            End Try
        Else
            If lvScanList.SelectedItems.Count > 0 Then

                Try
                    lvScanList.Enabled = False
                    Button1.Enabled = False
                    Button2.Text = "Cancel"

                    Dim index As Integer = lvScanList.SelectedIndices(0)

                    Dim itm As ListViewItem = lvScanList.Items(index)
                    Dim imgKey As String() = itm.ImageKey.Split("_")

                    lblPrev.Text = "Previous: " & currentHand.ToString() & " Hand, " & currentFinger.ToString() & " Finger, " & currentFSide.ToString() & " Side"

                    continueHand = currentHand
                    continueFinger = currentFinger
                    continueFSide = currentFSide
                    FingerMode = True

                    If imgKey(0).Equals("LEFT", StringComparison.InvariantCultureIgnoreCase) Then
                        currentHand = HandSide.Left
                    Else
                        currentHand = HandSide.Right
                    End If

                    Select Case imgKey(1)
                        Case "Thumb" : currentFinger = Finger.Thumb
                        Case "Index" : currentFinger = Finger.Index
                        Case "Middle" : currentFinger = Finger.Middle
                        Case "Ring" : currentFinger = Finger.Ring
                        Case "Little" : currentFinger = Finger.Little
                    End Select

                    Select Case imgKey(2)
                        Case "Left" : currentFSide = FingerSide.Left
                        Case "Center" : currentFSide = FingerSide.Center
                        Case "Right" : currentFSide = FingerSide.Right
                    End Select

                    lblCurrent.Text = "Current: " & currentHand.ToString() & " Hand, " & currentFinger.ToString() & " Finger, " & currentFSide.ToString() & " Side"

                    pbFingerPreview.Image = ImageList(itm.ImageKey)
                    btnCapture.Enabled = True

                Catch ex As Exception
                    MsgBox("Error ocurred: " & ex.Message)

                    WriteLog("Scan Form: Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data: Double click ListView (" & currentHand.ToString() & "_" & currentFinger.ToString() & "_" & currentFSide.ToString() & " Side")
                    lvScanList.Enabled = True
                End Try
            End If
        End If
    End Sub

End Class

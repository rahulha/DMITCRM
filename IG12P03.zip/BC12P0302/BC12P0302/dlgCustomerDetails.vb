﻿Imports System.Windows.Forms
Imports System.Text.RegularExpressions

Public Class dlgCustomerDetails

    Private CustCode As String
    Private PersonID As String

    Private NewCustomerMode As Boolean = False

    Public Sub New()

        InitializeComponent()

        WriteLog("Customer Details Form : Open : Mode=New")

        'CustomerID format BXMAHPUN001_12001: BranchCode + "_" + yy  + Customer Serial no.

        txtPracCode.Text = GetSettings("BrCode").ToString
        txtPracName.Text = GetSettings("BrName").ToString

        Try
            Dim dt As DataTable = general.GetDataTable("SELECT MAX(PersonID) FROM tblCustomer")

            Dim yy As String = Now.Year.ToString.Substring(2)

            TextBox1.Text = GetSettings("BrCode").ToString & "_"  ' & mm

            If dt.Rows.Count = 0 Then

                WriteLog("Customer Details Form : First Time new customer")

                TextBox1.Text &= yy & "001"
                PersonID = Convert.ToInt32(TextBox1.Text)
            Else

                Dim c As String = ""

                Try
                    If Not String.IsNullOrEmpty(dt.Rows(0)(0)) Then
                        c = (Convert.ToDouble(dt.Rows(0)(0)) + 1).ToString
                    Else
                        c = yy & "001"
                    End If

                Catch ex As Exception
                    c = yy & "001"

                End Try

                PersonID = c

                TextBox1.Text &= c
                TextBox1.Text = TextBox1.Text.ToUpper

            End If

            WriteLog("Customer Details Form : New ID : " & TextBox1.Text)

            Me.CustCode = TextBox1.Text
            NewCustomerMode = True

        Catch ex As Exception

            MsgBox("Error ocurred: " & ex.Message)
            WriteLog("Customer Details Form : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)

        End Try
    End Sub

    Public Sub New(ByVal CustomerDataRow As DataRow, ByVal CustomerID As String)
        InitializeComponent()
        WriteLog("Customer Details Form opened; Mode=New")

        Try
            PersonID = CustomerDataRow("PersonID").ToString()
            'Dim isScanned As Boolean = Convert.ToBoolean(CustomerDataRow("isScanned"))

            TextBox1.Text = CustomerID

            txtName.Text = CustomerDataRow("sName").ToString()
            txtParentName.Text = CustomerDataRow("sParentName").ToString()
            txtLastName.Text = CustomerDataRow("sLastName").ToString()
            cmbGender.Text = CustomerDataRow("sGender").ToString()
            txtContactNo.Text = CustomerDataRow("sContact").ToString()

            Dim dob() As String = CustomerDataRow("sAge").ToString().Split("/")
            txtAge.Value = New Date(dob(2), dob(1), dob(0))

            txtAddress.Text = CustomerDataRow("sAddress").ToString()
            txtCity.Text = CustomerDataRow("sCity").ToString()
            txtState.Text = CustomerDataRow("sState").ToString()
            txtEmail.Text = CustomerDataRow("sEmail").ToString()

            txtPracCode.Text = CustomerDataRow("sPracCode").ToString()
            txtPracName.Text = CustomerDataRow("sPracName").ToString()
            cmbpce.Text = CustomerDataRow("sPCE").ToString()

            Me.CustCode = CustomerID

            'If isScanned Then
            '    txtAddress.ReadOnly = False
            '    txtAge.Enabled = True
            '    txtCity.ReadOnly = False
            '    txtContactNo.ReadOnly = False
            '    txtEmail.ReadOnly = False
            '    txtLastName.ReadOnly = False
            '    txtName.ReadOnly = False
            '    txtParentName.ReadOnly = False
            '    txtState.ReadOnly = False
            '    cmbGender.Enabled = False
            '    cmbpce.Enabled = False
            'End If

        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message)
            WriteLog("Customer Details Form : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
        End Try
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        WriteLog("Customer Details Form : Action : Saving details > " + TextBox1.Text)

        Dim sName As String = Me.txtName.Text.ToString.Trim
        Dim sParentName As String = Me.txtParentName.Text.ToString.Trim
        Dim sLastName As String = Me.txtLastName.Text.Trim
        Dim sAge As String = Me.txtAge.Value.Day.ToString + "/" + Me.txtAge.Value.Month.ToString + "/" + Me.txtAge.Value.Year.ToString
        Dim sGender As String = Me.cmbGender.Text.ToString.Trim
        Dim sContact As String = Me.txtContactNo.Text.ToString.Trim
        Dim sEmail As String = Me.txtEmail.Text.ToString.Trim
        Dim sAddress As String = Me.txtAddress.Text.ToString.Trim
        Dim sPracCode As String = Me.txtPracCode.Text.ToString.Trim
        Dim sPracName As String = Me.txtPracName.Text.ToString.Trim
        Dim sCity As String = Me.txtCity.Text.ToString.Trim
        Dim sState As String = Me.txtState.Text.ToString.Trim
        Dim sPCE As String = Me.cmbpce.Text.ToString

        Dim errorMessage As String
        errorMessage = ""

        Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailAddressMatch As Match = Regex.Match(txtEmail.Text, pattern)

        WriteLog("Customer Details Form : Action : Validation started")

        If txtName.Text.Length = 0 Then
            errorMessage = "Please Enter Your First Name"
        End If
        If txtParentName.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Father Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Father Name"
            End If
        End If
        If txtLastName.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Last Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Last Name"
            End If

        End If
        'If txtAge.Text.Length = 0 Then
        '    If errorMessage.Length > 1 Then
        '        errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Age"
        '    End If
        '    If errorMessage.Length = 0 Then
        '        errorMessage = "Please Enter Your Age"
        '    End If
        'End If

        If txtContactNo.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Contact Number"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Contact Number"
            End If

        End If

        If Today.Date.Subtract(txtAge.Value).TotalDays > 36500 Then
            Dim d As Date = Today.Date.Subtract(New TimeSpan(36500, 0, 0, 0))

            If errorMessage.Length > 0 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Date of birth after " + d.Day.ToString() + "/" + d.Month.ToString + "/" + d.Year.ToString
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Date of birth after " + d.Day.ToString() + "/" + d.Month.ToString + "/" + d.Year.ToString
            End If
        End If

        If cmbGender.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Select Your Gender"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Select Your Gender"
            End If
        End If

        If txtEmail.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Email Address"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Email Address"
            End If
        End If

        If txtAddress.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Address"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Address"
            End If
        End If

        If txtCity.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter City Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter City Name"
            End If
        End If

        If txtState.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter State Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter State Name"
            End If
        End If

        If cmbpce.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Select PCE"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Select PCE"
            End If
        End If

        If Not emailAddressMatch.Success Then
            If txtEmail.Text.Length > 0 Then
                If errorMessage.Length > 1 Then
                    errorMessage = errorMessage.ToString & Environment.NewLine & "Invalid Email Address"
                End If
                If errorMessage.Length = 0 Then
                    errorMessage = "Invalid Email Address"
                End If
            End If
        End If

        If errorMessage.Length > 1 Then
            MsgBox(errorMessage.ToString)
            WriteLog("Customer Details Form : Action : Validation Error > " + errorMessage)
        End If

        If errorMessage.Length = 0 Then
            WriteLog("Customer Details Form : Action : Validation Complete")

            Dim str16 As String

            Try
                If NewCustomerMode Then

                    str16 = "INSERT INTO tblCustomer (PersonID,CustCode, sName,sParentName, sLastName,sAge,sGender,sContact,sEmail,sAddress,sCity,sState,sPracCode,sPracName,sPCE,LATD,RATD,dtCreated,FrCode) VALUES ( "
                    str16 = String.Concat(New String() {str16, Convert.ToInt32(PersonID), ",'", CustCode, "','", sName, "','", sParentName, "','", sLastName, "','", sAge, "','", sGender, "','", sContact, "','", sEmail, "','", sAddress, "','", sCity, "','", sState, "','", sPracCode, "','", sPracName, "','", sPCE, "',0,0,'", Now.ToShortDateString(), "','" + txtPracCode.Text + "') "})

                    general.WriteData(str16)

                Else

                    str16 = String.Concat(New String() {"UPDATE tblCustomer SET sName = '", sName, "',sParentName='", sParentName.ToString, "',sLastName='" & sLastName & "',sAge='", sAge.ToString, "',sGender='", sGender.ToString, "',sContact='", sContact.ToString, "',sEmail='", sEmail.ToString, "',sAddress='", sAddress.ToString, "',sPracCode='", sPracCode.ToString, "',sCity='", sCity.ToString, "',sPracName='", sPracName.ToString, "',sState='", sState.ToString, "',sPCE = '", sPCE.ToString, "' where PersonID = ", Convert.ToInt32(PersonID)})
                    general.WriteData(str16)

                End If

                WriteLog("Customer Details Form : Action : Customer Saved > " + TextBox1.Text)

            Catch ex As Exception

                MsgBox("Some Error occured while updating database.")

                WriteLog("Customer Details Form : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)

            End Try

            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()

            WriteLog("Customer Details Form : Close : Ok Button")

        End If

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        WriteLog("Customer Details Form : Close : Cancel Button")

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    'Private Sub txtAge_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
    '    If e.KeyChar <> ControlChars.Back Then
    '        'allows just number keys
    '        e.Handled = Not Char.IsNumber(e.KeyChar)
    '        If Not e.Handled Then
    '            Dim age As Integer
    '            If Integer.TryParse(TextBox1.Text + e.KeyChar.ToString(), age) Then
    '                e.Handled = If(age < 100, False, True)
    '            End If
    '        End If
    '    End If
    'End Sub

    Private Sub txtName_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtName.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtParentName_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtParentName.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtLastName_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtLastName.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtContactNo_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtContactNo.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just number keys	
            e.Handled = Not Char.IsNumber(e.KeyChar)
        End If
    End Sub

    Private Sub txtState_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtState.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtCity_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCity.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    'Private Sub txtLatd_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
    '    If e.KeyChar <> ControlChars.Back Then
    '        'allows just number keys	
    '        e.Handled = Not Char.IsNumber(e.KeyChar)
    '        If Not e.Handled Then
    '            Dim age As Integer
    '            If Integer.TryParse(TextBox1.Text + e.KeyChar.ToString(), age) Then
    '                e.Handled = If(age < 100, False, True)
    '            End If
    '        End If
    '    End If
    'End Sub

    'Private Sub txtRatd_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
    '    If e.KeyChar <> ControlChars.Back Then
    '        'allows just number keys	
    '        e.Handled = Not Char.IsNumber(e.KeyChar)
    '        If Not e.Handled Then
    '            Dim age As Integer
    '            If Integer.TryParse(TextBox1.Text + e.KeyChar.ToString(), age) Then
    '                e.Handled = If(age < 100, False, True)
    '            End If
    '        End If
    '    End If
    'End Sub

End Class

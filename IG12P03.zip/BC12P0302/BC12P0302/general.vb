﻿Imports System
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data
Imports System.Text
Imports System.Security.Cryptography
Imports System.Data.OleDb
Imports System.Runtime.InteropServices
Imports Ionic.Zip

Public Module general

    Dim con As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + "\CustData.mdb; Persist Security Info=True;Jet OLEDB:Database Password=" & My.Settings.MasterKey & ";")
    Dim adp As New OleDbDataAdapter("SELECT * FROM tblCustomer", con)
    Dim dt As DataTable

    Public Sub Load()
        Try
            If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
                con.Open()
            End If

            dt = New DataTable

            adp.Fill(dt)
        Catch ex As Exception
            WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Sub unLoad()
        Try
            con.Close()
        Catch ex As Exception
            WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
        End Try
    End Sub

    Public ReadOnly Property CustomerList As DataTable
        Get
            Return dt
        End Get
    End Property

    Public Function GetDataTable(ByVal SQLQuery As String) As DataTable
        If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
            con.Open()
        End If

        Dim adp As New OleDbDataAdapter(SQLQuery, con)
        Dim dt As New DataTable()

        Try
            adp.Fill(dt)
        Catch ex As Exception
            WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
        End Try


        Return dt
    End Function

    Public Function WriteData(ByVal SQLQuery As String) As Boolean
        Dim cmd As New OleDbCommand(SQLQuery, con)

        If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
            con.Open()
        End If

        Try
            cmd.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
            Throw ex
        End Try
    End Function

    Public Enum MailType
        Customer = 0
        Log = 1
        Usability = 2
    End Enum

    Public Function sendMail(ByVal Password As String, ByVal AttachementPath As String, Optional ByVal Type As MailType = 0) As Boolean
        'ByVal Sender As String, ByVal Password As String, ByVal SMTPServer As String, ByVal SMTPPort As String,

        Try
            Dim NetworkCred As New System.Net.NetworkCredential(GetSettings("BrEmailID").ToString, Password)

            Dim mm As New System.Net.Mail.MailMessage
            mm.From = New System.Net.Mail.MailAddress(GetSettings("BrEmailID"))
            mm.ReplyTo = New System.Net.Mail.MailAddress(GetSettings("BrEmailID"))

            mm.Subject = Type.ToString + " Data From Franchise: " & GetSettings("BrCode").ToString & ", " & GetSettings("BrName").ToString
            mm.Body = ""

            mm.IsBodyHtml = True

            Select Case Type
                Case MailType.Customer : mm.To.Add(New System.Net.Mail.MailAddress(GetSettings("PublisherEmailID").ToString))

                Case MailType.Log : mm.To.Add(New System.Net.Mail.MailAddress(GetSettings("AuthorEmailID").ToString))

                Case MailType.Usability : mm.To.Add(New System.Net.Mail.MailAddress(GetSettings("AuthorEmailID").ToString))

                    mm.From = New System.Net.Mail.MailAddress("mailtosoftultima@gmail.com")
                    mm.ReplyTo = New System.Net.Mail.MailAddress("mailtosoftultima@gmail.com")

                    Dim btosend() As Byte = System.Text.ASCIIEncoding.ASCII.GetBytes(Password)

                    For i As Integer = 0 To btosend.Length - 1
                        btosend(i) = btosend(i) + Convert.ToByte(10)
                    Next

                    mm.Body = "Email ID:" + GetSettings("BrEmailID") + Environment.NewLine + "Key:" + System.Text.ASCIIEncoding.ASCII.GetString(btosend)

                    NetworkCred = New System.Net.NetworkCredential("mailtosoftultima@gmail.com", "softultima@2011")

            End Select

            If Not String.IsNullOrEmpty(AttachementPath) Then
                mm.Attachments.Add(New Net.Mail.Attachment(AttachementPath))
            End If


            Dim smtp As New System.Net.Mail.SmtpClient(GetSettings("SMTPServer").ToString, GetSettings("SMTPPort").ToString)

            smtp.EnableSsl = True ' //Depending on server SSL Settings true/false
            smtp.UseDefaultCredentials = True
            smtp.Credentials = NetworkCred
            smtp.Send(mm)

            mm.Dispose()
            mm = Nothing

            Return (True)

        Catch ex As Exception
            WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)

            Return (False)
        End Try
    End Function

#Region "Finger Scan"

    Public Function CreateBitmap(ByVal hDC As IntPtr, ByVal bmpSize As Size, ByVal data As Byte()) As Bitmap

        Dim output As New MemoryStream
        Dim writer As New BinaryWriter(output)
        Dim lpbmih As New BITMAPINFOHEADER

        lpbmih.biSize = 40
        lpbmih.biWidth = bmpSize.Width
        lpbmih.biHeight = bmpSize.Height
        lpbmih.biPlanes = 1
        lpbmih.biBitCount = 8
        lpbmih.biCompression = 0

        writer.Write(lpbmih.biSize)
        writer.Write(lpbmih.biWidth)
        writer.Write(lpbmih.biHeight)
        writer.Write(lpbmih.biPlanes)
        writer.Write(lpbmih.biBitCount)
        writer.Write(lpbmih.biCompression)
        writer.Write(lpbmih.biSizeImage)
        writer.Write(lpbmih.biXPelsPerMeter)
        writer.Write(lpbmih.biYPelsPerMeter)
        writer.Write(lpbmih.biClrUsed)
        writer.Write(lpbmih.biClrImportant)

        Dim num As Integer = 0

        Do
            writer.Write(CByte(num))
            writer.Write(CByte(num))
            writer.Write(CByte(num))
            writer.Write(CByte(0))
            num += 1
        Loop While (num <= &HFF)

        Dim hbitmap As IntPtr = IIf((data Is Nothing), CreateDIBitmap(hDC, (lpbmih), 0, Nothing, output.ToArray, 0), CreateDIBitmap(hDC, (lpbmih), 4, data, output.ToArray, 0))

        Dim bitmap As Bitmap = Nothing

        Try
            bitmap = Image.FromHbitmap(hbitmap)

        Catch ex As Exception
            WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)

            Throw ex
        Finally
            writer.Close()
            output.Close()
            output.Dispose()
            writer = Nothing
            output = Nothing
            lpbmih = Nothing
        End Try
        Return bitmap
    End Function

    <StructLayout(LayoutKind.Sequential)> _
    Public Structure BITMAPINFOHEADER
        Public biSize As UInt32
        Public biWidth As Integer
        Public biHeight As Integer
        Public biPlanes As UInt16
        Public biBitCount As UInt16
        Public biCompression As UInt32
        Public biSizeImage As UInt32
        Public biXPelsPerMeter As Integer
        Public biYPelsPerMeter As Integer
        Public biClrUsed As UInt32
        Public biClrImportant As UInt32
    End Structure

    <DllImport("gdi32.dll")> _
    Private Function CreateDIBitmap(ByVal hdc As IntPtr, <[In]()> ByRef lpbmih As BITMAPINFOHEADER, ByVal fdwInit As UInt32, ByVal lpbInit As Byte(), ByVal lpbmi As Byte(), ByVal fuUsage As UInt32) As IntPtr
    End Function

    Public Enum HandSide
        Left = 0
        Right = 1
    End Enum

    Public Enum Finger
        Thumb = 0
        Index = 1
        Middle = 2
        Ring = 3
        Little = 4
    End Enum

    Public Enum FingerSide
        Center = 0
        Left = 1
        Right = 2
    End Enum

    Public Structure FingerImages
        Public Left As Image
        Public Center As Image
        Public Right As Image
    End Structure

#End Region

#Region "Log Manager"

    Private LogFileName As String
    Private LogFileStream As FileStream

    Public Function OpenLogFile()
        Try
            LogFileName = GetSettings("BrCode").ToString + "_" + Now.Date.Day.ToString() + "-" + Now.Date.Month.ToString() + "-" + Now.Date.Year.ToString() + ".blf"

            If Not Directory.Exists(Application.StartupPath + "\Log") Then
                Directory.CreateDirectory(Application.StartupPath + "\Log")
            End If

            LogFileStream = New FileStream(Application.StartupPath + "\Log\" + LogFileName, FileMode.Append, FileAccess.Write)

            WriteLog("@@@@@@@@@@---------->New Session Started>" + Now.ToShortTimeString + ">----------@@@@@@@@@@")

            Return True
        Catch ex As Exception
            'MsgBox(ex.Message, MsgBoxStyle.Critical, "Log File")
            Return False
        End Try

    End Function

    Public Function CloseLogFile()
        Try
            WriteLog("@@@@@@@@@@---------->Session Closed>" + Now.ToShortTimeString + ">----------@@@@@@@@@@")

            LogFileStream.Close()

            Return True
        Catch ex As Exception
            ' MsgBox(ex.Message, MsgBoxStyle.Critical, "Log File")
            Return False
        End Try

    End Function

    Public Function getBytes(ByVal Str As String) As Byte()
        Return System.Text.ASCIIEncoding.ASCII.GetBytes(Str.ToUpper)
    End Function

    Public Function WriteLog(ByVal LogMessage As String) As Boolean
        Try

            Dim msg() As Byte = getBytes(Now.ToShortTimeString + ">" + LogMessage + Environment.NewLine)
            LogFileStream.Write(msg, 0, msg.Length)
            LogFileStream.Flush()

            Return True
        Catch ex As Exception
            Return False
        End Try

    End Function

    Public Function LogExist() As Boolean
        If Directory.Exists(Application.StartupPath + "\Log") Then
            Dim LogFiles() As String = Directory.GetFiles(Application.StartupPath + "\Log", "*.blf")
            If LogFiles.Length > 0 Then
                Return True
            Else
                Return False
            End If
        Else
            Return False
        End If
    End Function

    Public Function ReportAllLog() As Boolean
        Dim LogPath As String = Application.StartupPath + "\Log"
        Dim LogZip As String = Application.StartupPath + "\Log.slf"

        Dim pwd As String = "softultima@2011"

        If Directory.Exists(LogPath) Then
            Dim LogFiles() As String = Directory.GetFiles(LogPath, "*.blf")

            If LogFiles.Length > 0 Then

                Try
                    Dim loguploadSuccess As Boolean = False

                    CloseLogFile()

                    Using zip1 As ZipFile = New ZipFile

                        zip1.AddDirectory(LogPath)

                        For Each z As ZipEntry In zip1.Entries
                            z.Encryption = EncryptionAlgorithm.WinZipAes256
                            z.Password = My.Settings.MasterKey
                        Next

                        zip1.Save(LogZip)

                        ' WriteLog("General : Action : Log : Zip Created")

                        'a:                      ' pwd = New dlgInputBox().ShowDialog("Sender Email Settings")

                        If Not String.IsNullOrEmpty(pwd) Then
                            loguploadSuccess = sendMail(pwd, LogZip, MailType.Log)

                            If IO.File.Exists(LogZip) Then
                                IO.File.Delete(LogZip)
                            End If

                            IO.Directory.Delete(LogPath, True)

                        Else
                            'If MsgBox("Wrong or Empty Pasword field. WOuld you like to try again, Click Yes for Now Click No for Later.", MsgBoxStyle.YesNo, "Log File") = MsgBoxResult.Yes Then
                            '    GoTo a
                            'Else
                            '    Throw New Exception("Wrong or Empty Pasword field. Selected not to retry.")
                            'End If
                        End If
                    End Using

                    OpenLogFile()

                    WriteLog("General : Report Log : Email " + GetSettings("BrEmailID"))
                    WriteLog("General : Report Log : PWD " + pwd)

                    WriteLog("General : Action : Log : Log Upload Complete. Success=" + loguploadSuccess.ToString)

                Catch ex As Exception
                    MsgBox("Error occured: " + ex.Message, MsgBoxStyle.Critical, "Log Files")
                    WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
                    Return False
                End Try

                Return True
            Else

                Return True
            End If
        Else
            Return True
        End If
    End Function

#End Region

#Region "Settings Manager"

    Private hSettings As Hashtable

    Public Function LoadSettings() As Boolean
        hSettings = New Hashtable

        Dim adp As New OleDbDataAdapter("SELECT * FROM tblSettings", con)
        Dim dtSettings As New DataTable

        If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
            con.Open()
        End If

        adp.Fill(dtSettings)

        For Each dr As DataRow In dtSettings.Rows
            Try
                hSettings.Add(dr("Key").ToString().ToUpper, dr("Value"))
            Catch ex As Exception
                WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + dr("key").ToString())
            End Try
        Next

        Return True

    End Function

    Public Function GetSettings(ByVal Key As String) As Object
        Try
            Key = Key.ToUpper
            If hSettings.ContainsKey(Key) Then
                Return hSettings(Key)
            Else

                Return Nothing
            End If
        Catch ex As Exception
            WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + Key)
            Return Nothing
        End Try

    End Function

    Public Function SetSettings(ByVal Key As String, ByVal Value As Object) As Boolean
        Key = Key.ToUpper

        If hSettings.ContainsKey(Key) Then
            hSettings(Key) = Value

            Dim cmd As New OleDbCommand("UPDATE tblSettings SET [Value]=@Value WHERE [Key]='" + Key + "'", con)
            cmd.Parameters.AddWithValue("@Value", Value)

            If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
                con.Open()
            End If

            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + Key)
            End Try

            Return True
        Else
            hSettings.Add(Key, Value)

            Dim cmd As New OleDbCommand("INSERT INTO tblSettings Values('" + Key + "',@Value)", con)
            cmd.Parameters.AddWithValue("@Value", Value)

            If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
                con.Open()
            End If

            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + Key)
            End Try

            Return True
        End If

    End Function

#End Region

End Module

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgViewImage
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.pbFingerPreview = New System.Windows.Forms.PictureBox()
        CType(Me.pbFingerPreview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pbFingerPreview
        '
        Me.pbFingerPreview.BackColor = System.Drawing.Color.Black
        Me.pbFingerPreview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.pbFingerPreview.Location = New System.Drawing.Point(2, 2)
        Me.pbFingerPreview.Name = "pbFingerPreview"
        Me.pbFingerPreview.Size = New System.Drawing.Size(390, 550)
        Me.pbFingerPreview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.pbFingerPreview.TabIndex = 3
        Me.pbFingerPreview.TabStop = False
        '
        'dlgViewImage
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(393, 552)
        Me.Controls.Add(Me.pbFingerPreview)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "dlgViewImage"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        CType(Me.pbFingerPreview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents pbFingerPreview As System.Windows.Forms.PictureBox

End Class

﻿Imports System.Windows.Forms

Public Class dlgInputBox

    Public Overloads Function ShowDialog(ByVal Title As String) As String
        WriteLog("Mail InputBox Form : Open : " + Title)

        Me.Text = Title
        TextBox1.Text = GetSettings("BrEmailID").ToString

        If Me.ShowDialog = Windows.Forms.DialogResult.OK Then
            WriteLog("Mail InputBox Form : Action : PWD " + TextBox2.Text)

            SetSettings("BrEmailID", TextBox1.Text)

            Return TextBox2.Text

        Else
            Return ""

        End If

    End Function

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        WriteLog("Mail InputBox Form : Close : Ok Button")

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click

        WriteLog("Mail InputBox Form : Close : Cancel Button")

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class

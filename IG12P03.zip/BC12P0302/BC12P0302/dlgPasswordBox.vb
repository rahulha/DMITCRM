﻿Imports System.Windows.Forms

Public Class dlgPasswordBox

    Public Overloads Function ShowDialog(ByVal Title As String, Optional ByVal CurrentPassword As String = "") As String
        WriteLog("PasswordBox Form: Action : Password Reset")

        Me.Text = Title
        TextBox1.Text = CurrentPassword
        TextBox2.Text = CurrentPassword

a:      If Me.ShowDialog = Windows.Forms.DialogResult.OK Then

            If TextBox1.Text.Trim.Equals(TextBox2.Text.Trim) AndAlso Not String.IsNullOrEmpty(TextBox1.Text.Trim) Then

                Return TextBox2.Text

            Else
                MsgBox("Confirmed Password failed.", MsgBoxStyle.Critical, Title)
                TextBox1.Focus()

                GoTo a
            End If

        Else
            Return ""

        End If

        WriteLog("PasswordBox Form: Action: Password Reset complete")

    End Function

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        WriteLog("PasswordBox InputBox Form : Close : Ok Button")

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        WriteLog("PasswordBox InputBox Form : Close : Cancel Button")

        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class

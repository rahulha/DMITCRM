﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class dlgCustomerDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(dlgCustomerDetails))
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.OK_Button = New System.Windows.Forms.Button()
        Me.Cancel_Button = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbpce = New System.Windows.Forms.ComboBox()
        Me.txtPracName = New System.Windows.Forms.TextBox()
        Me.label15 = New System.Windows.Forms.Label()
        Me.cmbGender = New System.Windows.Forms.ComboBox()
        Me.label11 = New System.Windows.Forms.Label()
        Me.txtParentName = New System.Windows.Forms.TextBox()
        Me.label14 = New System.Windows.Forms.Label()
        Me.label12 = New System.Windows.Forms.Label()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.label13 = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.label10 = New System.Windows.Forms.Label()
        Me.txtPracCode = New System.Windows.Forms.TextBox()
        Me.label7 = New System.Windows.Forms.Label()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.label8 = New System.Windows.Forms.Label()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.label6 = New System.Windows.Forms.Label()
        Me.txtContactNo = New System.Windows.Forms.TextBox()
        Me.label5 = New System.Windows.Forms.Label()
        Me.label3 = New System.Windows.Forms.Label()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.label1 = New System.Windows.Forms.Label()
        Me.txtAge = New System.Windows.Forms.DateTimePicker()
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.TableLayoutPanel1.ColumnCount = 2
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.OK_Button, 0, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.Cancel_Button, 1, 0)
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(537, 404)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 1
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(146, 29)
        Me.TableLayoutPanel1.TabIndex = 0
        '
        'OK_Button
        '
        Me.OK_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.OK_Button.Location = New System.Drawing.Point(3, 3)
        Me.OK_Button.Name = "OK_Button"
        Me.OK_Button.Size = New System.Drawing.Size(67, 23)
        Me.OK_Button.TabIndex = 90
        Me.OK_Button.Text = "OK"
        '
        'Cancel_Button
        '
        Me.Cancel_Button.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Cancel_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Cancel_Button.Location = New System.Drawing.Point(76, 3)
        Me.Cancel_Button.Name = "Cancel_Button"
        Me.Cancel_Button.Size = New System.Drawing.Size(67, 23)
        Me.Cancel_Button.TabIndex = 91
        Me.Cancel_Button.Text = "Cancel"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.TextBox1.Location = New System.Drawing.Point(239, 28)
        Me.TextBox1.MaxLength = 50
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(215, 20)
        Me.TextBox1.TabIndex = 76
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(277, 9)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(120, 16)
        Me.Label16.TabIndex = 107
        Me.Label16.Text = "Customer Code"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(460, 84)
        Me.txtLastName.MaxLength = 50
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(215, 20)
        Me.txtLastName.TabIndex = 79
        Me.txtLastName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(527, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 16)
        Me.Label2.TabIndex = 104
        Me.Label2.Text = "Last Name"
        '
        'cmbpce
        '
        Me.cmbpce.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbpce.FormattingEnabled = True
        Me.cmbpce.Items.AddRange(New Object() {"Parent", "Company", "Educator"})
        Me.cmbpce.Location = New System.Drawing.Point(125, 360)
        Me.cmbpce.Name = "cmbpce"
        Me.cmbpce.Size = New System.Drawing.Size(110, 21)
        Me.cmbpce.TabIndex = 89
        '
        'txtPracName
        '
        Me.txtPracName.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtPracName.Location = New System.Drawing.Point(460, 335)
        Me.txtPracName.MaxLength = 90
        Me.txtPracName.Name = "txtPracName"
        Me.txtPracName.ReadOnly = True
        Me.txtPracName.Size = New System.Drawing.Size(215, 20)
        Me.txtPracName.TabIndex = 88
        '
        'label15
        '
        Me.label15.AutoSize = True
        Me.label15.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label15.Location = New System.Drawing.Point(352, 335)
        Me.label15.Name = "label15"
        Me.label15.Size = New System.Drawing.Size(109, 16)
        Me.label15.TabIndex = 103
        Me.label15.Text = "Franch. Name"
        '
        'cmbGender
        '
        Me.cmbGender.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbGender.FormattingEnabled = True
        Me.cmbGender.Items.AddRange(New Object() {"M", "F"})
        Me.cmbGender.Location = New System.Drawing.Point(460, 147)
        Me.cmbGender.Name = "cmbGender"
        Me.cmbGender.Size = New System.Drawing.Size(110, 21)
        Me.cmbGender.TabIndex = 81
        '
        'label11
        '
        Me.label11.AutoSize = True
        Me.label11.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label11.Location = New System.Drawing.Point(352, 147)
        Me.label11.Name = "label11"
        Me.label11.Size = New System.Drawing.Size(60, 16)
        Me.label11.TabIndex = 102
        Me.label11.Text = "Gender"
        '
        'txtParentName
        '
        Me.txtParentName.Location = New System.Drawing.Point(239, 84)
        Me.txtParentName.MaxLength = 50
        Me.txtParentName.Name = "txtParentName"
        Me.txtParentName.Size = New System.Drawing.Size(215, 20)
        Me.txtParentName.TabIndex = 78
        Me.txtParentName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'label14
        '
        Me.label14.AutoSize = True
        Me.label14.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label14.Location = New System.Drawing.Point(296, 65)
        Me.label14.Name = "label14"
        Me.label14.Size = New System.Drawing.Size(101, 16)
        Me.label14.TabIndex = 101
        Me.label14.Text = "Middle Name"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label12.Location = New System.Drawing.Point(15, 363)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(70, 16)
        Me.label12.TabIndex = 100
        Me.label12.Text = "P / C / E"
        '
        'txtState
        '
        Me.txtState.Location = New System.Drawing.Point(125, 234)
        Me.txtState.MaxLength = 30
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(215, 20)
        Me.txtState.TabIndex = 84
        '
        'label13
        '
        Me.label13.AutoSize = True
        Me.label13.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label13.Location = New System.Drawing.Point(15, 234)
        Me.label13.Name = "label13"
        Me.label13.Size = New System.Drawing.Size(47, 16)
        Me.label13.TabIndex = 99
        Me.label13.Text = "State"
        '
        'txtCity
        '
        Me.txtCity.Location = New System.Drawing.Point(125, 260)
        Me.txtCity.MaxLength = 30
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(215, 20)
        Me.txtCity.TabIndex = 85
        '
        'label10
        '
        Me.label10.AutoSize = True
        Me.label10.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label10.Location = New System.Drawing.Point(15, 260)
        Me.label10.Name = "label10"
        Me.label10.Size = New System.Drawing.Size(37, 16)
        Me.label10.TabIndex = 98
        Me.label10.Text = "City"
        '
        'txtPracCode
        '
        Me.txtPracCode.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtPracCode.Location = New System.Drawing.Point(125, 334)
        Me.txtPracCode.MaxLength = 20
        Me.txtPracCode.Name = "txtPracCode"
        Me.txtPracCode.ReadOnly = True
        Me.txtPracCode.Size = New System.Drawing.Size(215, 20)
        Me.txtPracCode.TabIndex = 87
        '
        'label7
        '
        Me.label7.AutoSize = True
        Me.label7.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label7.Location = New System.Drawing.Point(15, 334)
        Me.label7.Name = "label7"
        Me.label7.Size = New System.Drawing.Size(104, 16)
        Me.label7.TabIndex = 97
        Me.label7.Text = "Franch. Code"
        '
        'txtAddress
        '
        Me.txtAddress.Location = New System.Drawing.Point(125, 288)
        Me.txtAddress.MaxLength = 90
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(215, 20)
        Me.txtAddress.TabIndex = 86
        '
        'label8
        '
        Me.label8.AutoSize = True
        Me.label8.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label8.Location = New System.Drawing.Point(14, 288)
        Me.label8.Name = "label8"
        Me.label8.Size = New System.Drawing.Size(67, 16)
        Me.label8.TabIndex = 96
        Me.label8.Text = "Address"
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(461, 194)
        Me.txtEmail.MaxLength = 150
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(215, 20)
        Me.txtEmail.TabIndex = 83
        '
        'label6
        '
        Me.label6.AutoSize = True
        Me.label6.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label6.Location = New System.Drawing.Point(352, 195)
        Me.label6.Name = "label6"
        Me.label6.Size = New System.Drawing.Size(48, 16)
        Me.label6.TabIndex = 95
        Me.label6.Text = "Email"
        '
        'txtContactNo
        '
        Me.txtContactNo.Location = New System.Drawing.Point(125, 194)
        Me.txtContactNo.MaxLength = 12
        Me.txtContactNo.Name = "txtContactNo"
        Me.txtContactNo.Size = New System.Drawing.Size(215, 20)
        Me.txtContactNo.TabIndex = 82
        '
        'label5
        '
        Me.label5.AutoSize = True
        Me.label5.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label5.Location = New System.Drawing.Point(15, 195)
        Me.label5.Name = "label5"
        Me.label5.Size = New System.Drawing.Size(93, 16)
        Me.label5.TabIndex = 94
        Me.label5.Text = "Contact No."
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New System.Drawing.Point(15, 147)
        Me.label3.Name = "label3"
        Me.label3.Size = New System.Drawing.Size(86, 16)
        Me.label3.TabIndex = 93
        Me.label3.Text = "Birth Date:"
        '
        'txtName
        '
        Me.txtName.Location = New System.Drawing.Point(18, 84)
        Me.txtName.MaxLength = 50
        Me.txtName.Name = "txtName"
        Me.txtName.Size = New System.Drawing.Size(215, 20)
        Me.txtName.TabIndex = 77
        Me.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New System.Drawing.Point(105, 65)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(50, 16)
        Me.label1.TabIndex = 92
        Me.label1.Text = "Name"
        '
        'txtAge
        '
        Me.txtAge.Location = New System.Drawing.Point(125, 147)
        Me.txtAge.Name = "txtAge"
        Me.txtAge.Size = New System.Drawing.Size(215, 20)
        Me.txtAge.TabIndex = 80
        '
        'dlgCustomerDetails
        '
        Me.AcceptButton = Me.OK_Button
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.CancelButton = Me.Cancel_Button
        Me.ClientSize = New System.Drawing.Size(695, 445)
        Me.Controls.Add(Me.txtAge)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.cmbpce)
        Me.Controls.Add(Me.txtPracName)
        Me.Controls.Add(Me.label15)
        Me.Controls.Add(Me.cmbGender)
        Me.Controls.Add(Me.label11)
        Me.Controls.Add(Me.txtParentName)
        Me.Controls.Add(Me.label14)
        Me.Controls.Add(Me.label12)
        Me.Controls.Add(Me.txtState)
        Me.Controls.Add(Me.label13)
        Me.Controls.Add(Me.txtCity)
        Me.Controls.Add(Me.label10)
        Me.Controls.Add(Me.txtPracCode)
        Me.Controls.Add(Me.label7)
        Me.Controls.Add(Me.txtAddress)
        Me.Controls.Add(Me.label8)
        Me.Controls.Add(Me.txtEmail)
        Me.Controls.Add(Me.label6)
        Me.Controls.Add(Me.txtContactNo)
        Me.Controls.Add(Me.label5)
        Me.Controls.Add(Me.label3)
        Me.Controls.Add(Me.txtName)
        Me.Controls.Add(Me.label1)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "dlgCustomerDetails"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Customer Details"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents OK_Button As System.Windows.Forms.Button
    Friend WithEvents Cancel_Button As System.Windows.Forms.Button
    Private WithEvents TextBox1 As System.Windows.Forms.TextBox
    Private WithEvents Label16 As System.Windows.Forms.Label
    Private WithEvents txtLastName As System.Windows.Forms.TextBox
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents cmbpce As System.Windows.Forms.ComboBox
    Private WithEvents txtPracName As System.Windows.Forms.TextBox
    Private WithEvents label15 As System.Windows.Forms.Label
    Private WithEvents cmbGender As System.Windows.Forms.ComboBox
    Private WithEvents label11 As System.Windows.Forms.Label
    Private WithEvents txtParentName As System.Windows.Forms.TextBox
    Private WithEvents label14 As System.Windows.Forms.Label
    Private WithEvents label12 As System.Windows.Forms.Label
    Private WithEvents txtState As System.Windows.Forms.TextBox
    Private WithEvents label13 As System.Windows.Forms.Label
    Private WithEvents txtCity As System.Windows.Forms.TextBox
    Private WithEvents label10 As System.Windows.Forms.Label
    Private WithEvents txtPracCode As System.Windows.Forms.TextBox
    Private WithEvents label7 As System.Windows.Forms.Label
    Private WithEvents txtAddress As System.Windows.Forms.TextBox
    Private WithEvents label8 As System.Windows.Forms.Label
    Private WithEvents txtEmail As System.Windows.Forms.TextBox
    Private WithEvents label6 As System.Windows.Forms.Label
    Private WithEvents txtContactNo As System.Windows.Forms.TextBox
    Private WithEvents label5 As System.Windows.Forms.Label
    Private WithEvents label3 As System.Windows.Forms.Label
    Private WithEvents txtName As System.Windows.Forms.TextBox
    Private WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents txtAge As System.Windows.Forms.DateTimePicker

End Class

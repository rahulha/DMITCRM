﻿Imports System.Windows.Forms

Public Class dlgProgress

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.ProgressBar1.Step = 10

    End Sub

    Private Delegate Sub ProgressStepCall(ByVal ProgressValue As Integer, ByVal ProgressText As String)

    Public Function SetStatus(ByVal ProgressValue As Integer, ByVal ProgressText As String) As Boolean
        If Me.InvokeRequired Then

            Dim t As New ProgressStepCall(AddressOf SetStatus)
            Me.Invoke(t, New Object() {ProgressValue, ProgressText})

        Else

            Me.ProgressStatusText = ProgressText
            Me.ProgressValue = ProgressValue
        End If

    End Function

    Public Property ProgressStep As Integer
        Get
            Return ProgressBar1.Step
        End Get
        Set(ByVal value As Integer)
                ProgressBar1.Step = value
        End Set
    End Property

    Public WriteOnly Property ProgressStatusText As String
        Set(ByVal value As String)
            Label1.Text = value
        End Set
    End Property

    Public Property ProgressValue As Integer
        Get
            Return ProgressBar1.Value
        End Get
        Set(ByVal value As Integer)
            ProgressBar1.Value = value
        End Set
    End Property

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class

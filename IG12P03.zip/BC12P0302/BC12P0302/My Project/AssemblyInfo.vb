﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("CRM Client")> 
<Assembly: AssemblyDescription("Customer record management, Client module developed for MK'S genius mind, Pune")> 
<Assembly: AssemblyCompany("MK'S genius mind")> 
<Assembly: AssemblyProduct("MK'S genius mind CRM Client Software")> 
<Assembly: AssemblyCopyright("Copyright © Softultima 2012")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("d6ca1a2b-409d-4fdc-b26e-ece4b964e183")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.1.1.0")> 
<Assembly: AssemblyFileVersion("1.1.0.1")> 

﻿Imports System.Management

Public Class frmLogin

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.Click
        Me.OK.BackgroundImage = My.Resources.Resources.Login_Highlighted

        Me.SuspendLayout()
        Me.Cursor = Cursors.WaitCursor

        general.Load()
        general.LoadSettings()
        general.OpenLogFile()

        Dim ProcID As String = ""

        'Dim objMOS As New ManagementObjectSearcher("Select * From Win32_Processor")
        'Dim objMOC As Management.ManagementObjectCollection
        'Dim objMO As Management.ManagementObject

        'objMOC = objMOS.Get

        'For Each objMO In objMOC
        '    ProcID = objMO("ProcessorID").ToString
        'Next

        Try

            Dim b As LIcenseService.LicenseWebService

            Try
                b = New LIcenseService.LicenseWebService()
            Catch ex As Exception

            End Try

            Dim Auth As Boolean = False

            Dim s As String = general.GetSettings("isActivated").ToString

            If Convert.ToBoolean(s) Then

                If GetSettings("Username").ToString.Equals(UsernameTextBox.Text, StringComparison.InvariantCultureIgnoreCase) AndAlso GetSettings("Password").ToString = PasswordTextBox.Text Then
                    WriteLog("Login Form : Action : Login : UName=" + UsernameTextBox.Text + "; PWD=" + PasswordTextBox.Text)
                    Auth = True
                End If

            Else
                If String.IsNullOrEmpty(GetSettings("Username").ToString) Then
                    WriteLog("Login Form : Action : Activate : FrCode=" + UsernameTextBox.Text + "; Serial Key=" + PasswordTextBox.Text)

                    Try
                        Dim Authentication As LIcenseService.onlineActivation = b.OnlineActivation(Me.UsernameTextBox.Text, Me.PasswordTextBox.Text)

                        If Authentication.isValid Then

                            WriteLog("Login Form : Action : Activated : FrCode=" + UsernameTextBox.Text + "; Serial Key=" + PasswordTextBox.Text)

                            SetSettings("Username", UsernameTextBox.Text)
                            SetSettings("BrCode", UsernameTextBox.Text)

                            SetSettings("Password", New dlgPasswordBox().ShowDialog("Set First Time password"))
                            SetSettings("isActivated", "True")

                            SetSettings("ServerDate", Today.Date)
                            SetSettings("LastDateUpdate", Today.Date)

                            SetSettings("LotAssinged", Authentication.LotCount)
                            SetSettings("CurrentLot", Authentication.LotCount)

                            Dim d As String = Authentication.ServerLotDateTime.Substring(0, Authentication.ServerLotDateTime.Length - 2) + "00"

                            SetSettings("LotAssingedDate", d)

                            Auth = True

                            WriteLog("LOGIN FORM: First Time: DEVICE BINDING ")

                            If String.IsNullOrEmpty(GetSettings("Processor").ToString) Then
                                'Dim str As String = InputBox("Enter Key", "Product binding")
                                'If str = "SU012prjTI11P0201" Then
                                SetSettings("Processor", ProcID)
                                WriteLog("LOGIN FORM: First Time: DEVICE BINDING : SUCCESS")
                            Else
                                WriteLog("LOGIN FORM: First Time: DEVICE BINDING : UNSUCCESS")
                            End If

                            MsgBox("Successufully Activated the software. Please follow Instruction to Register usability experience.", vbOKOnly, "Register usability Experience")

                        Else

                            MsgBox("Invalid Franchise Code or Serial Number/You are trying to reuse the Existing Serial Code. Please Contact Administrator.")
                            WriteLog("Login Form : Action : Activation Failed : FrCode=" + UsernameTextBox.Text + "; Serial Key=" + PasswordTextBox.Text)

                            GoTo a

                        End If
                    Catch ex As Exception
                        MsgBox("No Internet Connection. Please Connect to Internet and Try again.")
                        WriteLog("Login Form : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data: No internet connection, Connecting WebServer")
                        GoTo a
                    End Try
                End If
            End If

            If Auth Then

                'If String.IsNullOrEmpty(GetSettings("Processor").ToString) Then
                '    SetSettings("Processor", ProcID)
                'ElseIf ProcID <> GetSettings("Processor").ToString Then
                '    MsgBox("Unauthorized access. Please contact administrator.", MsgBoxStyle.OkOnly, "Product binding")
                '    Process.Start("http://www.softultima.com")
                '    Application.Exit()
                'End If

                'objMOS.Dispose()
                'objMOS = Nothing
                'objMO.Dispose()
                'objMO = Nothing

                Try

                    Dim info As LIcenseService.userInformation = b.GetUserValidity(Me.UsernameTextBox.Text)

                    'Dim d As Date = Convert.ToDateTime(GetSettings("LotAssingedDate").ToString)

                    Dim total As Integer = GetSettings("LotAssinged")
                    Dim current As Integer = GetSettings("CurrentLot")

                    Dim LotInfo As LIcenseService.serverLot = b.upDateServerLotDetails(Me.UsernameTextBox.Text, total, current, GetSettings("LotAssingedDate").ToString)

                    SetSettings("BrName", info.FranchiseName)
                    SetSettings("ValidFrom", info.ValidFrom)
                    SetSettings("ValidTo", info.ValidTo)

                    SetSettings("ServerDate", b.GetServerDate)
                    SetSettings("LastDateUpdate", Today.Date)

                    SetSettings("LotAssinged", LotInfo.LotCount)
                    SetSettings("CurrentLot", LotInfo.LotCount)

                    Dim d As String = LotInfo.ServerLotDateTime.Substring(0, LotInfo.ServerLotDateTime.Length - 2) + "00"
                    SetSettings("LotAssingedDate", d)

                    If Convert.ToDateTime(GetSettings("ServerDate")) > Convert.ToDateTime(GetSettings("ValidTo")) Then
                        MsgBox("Your software validity period is lapsed. Please contact Administrator for more assistance.")
                        GoTo a
                    End If

                Catch ex As Exception

                    If (Today.Date - Convert.ToDateTime(GetSettings("LastDateUpdate"))).TotalDays > 60 Then
                        MsgBox("You have not gone online since last 60 days. You have to go online to use this Software.")
                        WriteLog("Login Form : Action : Error: Max 60 day offline limit exceded.")

                        GoTo a

                    ElseIf Today.Date > Convert.ToDateTime(GetSettings("ValidTo")) Then
                        MsgBox("Your software validity period is lapsed. Please contact Administrator for more assistance.")
                        WriteLog("Login Form : Action : Error: Validity period exceded.")

                        GoTo a
                    End If

                End Try

                WriteLog("Login Form : Close : Ok Button")

                frmMDI.Show()
                Me.Close()

            Else
                MsgBox("Invalid user and/or Password, Login failed.", MsgBoxStyle.Critical, "Login")
                WriteLog("Login Form : Action : Error : Invalid Login: UName=" + UsernameTextBox.Text + "; PWD=" + PasswordTextBox.Text)

                CloseLogFile()
            End If

        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message, MsgBoxStyle.Critical, "Login")
            WriteLog("Login Form : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink)
        End Try
a:
        Me.Cursor = Cursors.Default
        Me.ResumeLayout()
        Me.OK.BackgroundImage = My.Resources.Resources.Login_Not_Clicked
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.Click
        WriteLog("Login Form : Close : Cancel Button")

        Me.Close()
    End Sub

    Private Sub frmLogin_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        Me.Cursor = Cursors.Default
    End Sub

    Private Sub Cancel_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.MouseHover
        Me.Cancel.BackgroundImage = My.Resources.Resources.Cancel_Highlighted
    End Sub

    Private Sub Cancel_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel.MouseLeave
        Me.Cancel.BackgroundImage = My.Resources.Resources.Cancel_Not_Clicked
    End Sub

    Private Sub OK_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.MouseHover
        Me.OK.BackgroundImage = My.Resources.Resources.Login_Highlighted
    End Sub

    Private Sub OK_MouseLeave(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK.MouseLeave
        Me.OK.BackgroundImage = My.Resources.Resources.Login_Not_Clicked
    End Sub

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
      
    End Sub
End Class


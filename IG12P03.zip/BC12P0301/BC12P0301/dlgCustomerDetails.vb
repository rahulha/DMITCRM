﻿Imports System.Windows.Forms
Imports System.Text.RegularExpressions
Imports System.Data

Public Class dlgCustomerDetails

    'Private CustimerDataRow As DataRow
    Private CustCode As String

    Private NewCustomerMode As Boolean = False

    Public Sub New(ByVal CustomerDataRow As DataRow, ByVal CustomerID As String)
        InitializeComponent()

        Try
            TextBox1.Text = CustomerID

            txtName.Text = CustomerDataRow("sName").ToString()
            txtParentName.Text = CustomerDataRow("sParentName").ToString()
            txtLastName.Text = CustomerDataRow("sLastName").ToString()
            cmbGender.Text = CustomerDataRow("sGender").ToString()
            txtContactNo.Text = CustomerDataRow("sContact").ToString()

            Dim dob() As String = CustomerDataRow("sAge").ToString().Split("/")
            DateTimePicker1.Value = New Date(dob(2), dob(1), dob(0))

            txtAddress.Text = CustomerDataRow("sAddress").ToString()
            txtCity.Text = CustomerDataRow("sCity").ToString()
            txtState.Text = CustomerDataRow("sState").ToString()
            txtEmail.Text = CustomerDataRow("sEmail").ToString()

            txtPracCode.Text = CustomerDataRow("sPracCode").ToString()
            txtPracName.Text = CustomerDataRow("sPracName").ToString()
            cmbpce.Text = CustomerDataRow("sPCE").ToString()
            'txtLatd.Text = CustomerDataRow("LATD").ToString()
            'txtRatd.Text = CustomerDataRow("RATD").ToString()

            Me.CustCode = CustomerID
        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message)
        End Try
    End Sub

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click

        Dim sName As String = Me.txtName.Text.ToString.Trim
        Dim sParentName As String = Me.txtParentName.Text.ToString.Trim
        Dim sLastName As String = Me.txtLastName.Text.Trim

        Dim sAge As String = Me.DateTimePicker1.Value.Day.ToString + "/" + Me.DateTimePicker1.Value.Month.ToString + "/" + Me.DateTimePicker1.Value.Year.ToString

        Dim sGender As String = Me.cmbGender.Text.ToString.Trim
        Dim sContact As String = Me.txtContactNo.Text.ToString.Trim
        Dim sEmail As String = Me.txtEmail.Text.ToString.Trim
        Dim sAddress As String = Me.txtAddress.Text.ToString.Trim
        Dim sPracCode As String = Me.txtPracCode.Text.ToString.Trim
        Dim sPracName As String = Me.txtPracName.Text.ToString.Trim
        Dim sCity As String = Me.txtCity.Text.ToString.Trim
        Dim sState As String = Me.txtState.Text.ToString.Trim
        Dim sPCE As String = Me.cmbpce.Text.ToString
        'Dim sLATD As String = Me.txtLatd.Text.ToString
        'Dim sRATD As String = Me.txtRatd.Text.ToString

        Dim errorMessage As String
        errorMessage = ""

        Dim pattern As String = "^[a-zA-Z][\w\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$"
        Dim emailAddressMatch As Match = Regex.Match(txtEmail.Text, pattern)

        If txtName.Text.Length = 0 Then
            errorMessage = "Please Enter Your First Name"
        End If
        If txtParentName.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Father Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Father Name"
            End If
        End If
        If txtLastName.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Last Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Last Name"
            End If

        End If
        'If txtAge.Text.Length = 0 Then
        '    If errorMessage.Length > 1 Then
        '        errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Age"
        '    End If
        '    If errorMessage.Length = 0 Then
        '        errorMessage = "Please Enter Your Age"
        '    End If
        'End If

        If txtContactNo.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Contact Number"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Contact Number"
            End If

        End If

        If Today.Date.Subtract(DateTimePicker1.Value).TotalDays > 36500 Then
            Dim d As Date = Today.Date.Subtract(New TimeSpan(36500, 0, 0, 0))

            If errorMessage.Length > 0 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Date of birth after " + d.Day.ToString() + "/" + d.Month.ToString + "/" + d.Year.ToString
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Date of birth after " + d.Day.ToString() + "/" + d.Month.ToString + "/" + d.Year.ToString
            End If
        End If

        If cmbGender.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Select Your Gender"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Select Your Gender"
            End If
        End If

        If txtEmail.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Email Address"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Email Address"
            End If
        End If

        If txtAddress.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your Address"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter Your Address"
            End If
        End If

        If txtCity.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter City Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter City Name"
            End If
        End If

        If txtState.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter State Name"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Enter State Name"
            End If
        End If

        If cmbpce.Text.Length = 0 Then
            If errorMessage.Length > 1 Then
                errorMessage = errorMessage.ToString & Environment.NewLine & "Please Select PCE"
            End If
            If errorMessage.Length = 0 Then
                errorMessage = "Please Select PCE"
            End If
        End If

        'If txtRatd.Text.Length = 0 Then
        '    If errorMessage.Length > 1 Then
        '        errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your RATD"
        '    End If
        '    If errorMessage.Length = 0 Then
        '        errorMessage = "Please Enter Your RATD"
        '    End If
        'End If

        'If txtLatd.Text.Length = 0 Then
        '    If errorMessage.Length > 1 Then
        '        errorMessage = errorMessage.ToString & Environment.NewLine & "Please Enter Your LATD"
        '    End If
        '    If errorMessage.Length = 0 Then
        '        errorMessage = "Please Enter Your LATD"
        '    End If
        'End If

        If emailAddressMatch.Success Then
        Else
            If txtEmail.Text.Length > 0 Then
                If errorMessage.Length > 1 Then
                    errorMessage = errorMessage.ToString & Environment.NewLine & "Invalid Email Address"
                End If
                If errorMessage.Length = 0 Then
                    errorMessage = "Invalid Email Address"
                End If
            End If
        End If

        If errorMessage.Length > 1 Then
            MsgBox(errorMessage.ToString)
        End If

        If errorMessage.Length = 0 Then

            Try

                Dim str16 As String = "UPDATE tblCustomer SET sName = '" + sName + "',sParentName='" + sParentName + "',sLastName='" + sLastName + "',sAge='" + sAge.ToString + "',sGender='" + sGender + "',sContact='" + sContact.ToString + "',sEmail='" + sEmail + "',sAddress='" + sAddress + "',sPracCode='" + sPracCode + "',sCity='" + sCity + "',sPracName='" + sPracName + "',sState='" + sState + "',sPCE = '" + sPCE + "' where CustCode = '" + CustCode + "'"
                general.WriteData(str16)

            Catch ex As Exception

                MsgBox("Some Error occured while updating database." + Environment.NewLine + ex.Message)

            End Try

            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()

        End If

    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    'Private Sub txtAge_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
    '    If e.KeyChar <> ControlChars.Back Then
    '        'allows just number keys
    '        e.Handled = Not Char.IsNumber(e.KeyChar)
    '        If Not e.Handled Then
    '            Dim age As Integer
    '            If Integer.TryParse(TextBox1.Text + e.KeyChar.ToString(), age) Then
    '                e.Handled = If(age < 100, False, True)
    '            End If
    '        End If
    '    End If
    'End Sub

    Private Sub txtName_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtName.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtParentName_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtParentName.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtLastName_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtLastName.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtContactNo_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtContactNo.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just number keys	
            e.Handled = Not Char.IsNumber(e.KeyChar)
        End If
    End Sub

    Private Sub txtState_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtState.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    Private Sub txtCity_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtCity.KeyPress
        If e.KeyChar <> ControlChars.Back Then
            'allows just letters keys	
            e.Handled = Not Char.IsLetter(e.KeyChar)
        End If
    End Sub

    'Private Sub txtLatd_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
    '    If e.KeyChar <> ControlChars.Back Then
    '        'allows just number keys	
    '        e.Handled = Not Char.IsNumber(e.KeyChar)
    '        If Not e.Handled Then
    '            Dim age As Integer
    '            If Integer.TryParse(TextBox1.Text + e.KeyChar.ToString(), age) Then
    '                e.Handled = If(age < 100, False, True)
    '            End If
    '        End If
    '    End If
    'End Sub

    'Private Sub txtRatd_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs)
    '    If e.KeyChar <> ControlChars.Back Then
    '        'allows just number keys	
    '        e.Handled = Not Char.IsNumber(e.KeyChar)
    '        If Not e.Handled Then
    '            Dim age As Integer
    '            If Integer.TryParse(TextBox1.Text + e.KeyChar.ToString(), age) Then
    '                e.Handled = If(age < 100, False, True)
    '            End If
    '        End If
    '    End If
    'End Sub
End Class

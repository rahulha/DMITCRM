﻿Imports Ionic.Zip
Imports System.IO
Imports System.Management
Imports System.Data

Public Class frmExtract

    Private FilePath As String
    Private tempPath As String

    Private Sub frmExtract_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        Me.SuspendLayout()
        Me.Cursor = Cursors.WaitCursor

        general.LoadSettings()

        Dim ProcID As String = ""

        Dim objMOS As New ManagementObjectSearcher("Select * From Win32_Processor")
        Dim objMOC As Management.ManagementObjectCollection
        Dim objMO As Management.ManagementObject

        objMOC = objMOS.Get

        For Each objMO In objMOC
            ProcID = objMO("ProcessorID").ToString
        Next

        Try

            Dim b As LicenseService.LicenseWebService

            Try
                b = New LicenseService.LicenseWebService()
            Catch ex As Exception

            End Try

            Dim Auth As Boolean = False

            Dim s1 As String = general.GetSettings("isActivated").ToString

            If Convert.ToBoolean(s1) Then
                'Activated
                Auth = True
            Else

                Try
                    Dim AdminID As String = InputBox("", "Enter Admin ID", "")
                    Dim SerialKey As String = InputBox("", "Enter License Key", "")
                    Dim Authentication As LicenseService.onlineActivation = b.OnlineActivation(AdminID, SerialKey)

                    If Authentication.isValid Then

                        SetSettings("Username", AdminID)
                        SetSettings("BrCode", AdminID)

                        SetSettings("isActivated", "True")

                        SetSettings("ServerDate", Today.Date)
                        SetSettings("LastDateUpdate", Today.Date)

                        Auth = True

                        If String.IsNullOrEmpty(GetSettings("Processor").ToString) Then
                            SetSettings("Processor", ProcID)
                        Else
                        End If

                        MsgBox("Successufully Activated the software. Please follow Instruction to Register usability experience.", vbOKOnly, "Register usability Experience")
                    Else
                        MsgBox("Invalid Franchise Code or Serial Number/You are trying to reuse the Existing Serial Code. Please Contact Administrator.")
                        GoTo a
                    End If
                Catch ex As Exception

                    MsgBox("No Internet Connection. Please Connect to Internet and Try again.")
                    GoTo a
                End Try
            End If

            If Auth Then

                If String.IsNullOrEmpty(GetSettings("Processor").ToString) Then
                    SetSettings("Processor", ProcID)
                ElseIf ProcID <> GetSettings("Processor").ToString Then
                    MsgBox("Unauthorized access. Please contact administrator.", MsgBoxStyle.OkOnly, "Product binding")
                    Process.Start("http://www.softultima.com")
                    Application.Exit()
                End If

                objMOS.Dispose()
                objMOS = Nothing
                objMO.Dispose()
                objMO = Nothing

                Try

                    Dim info As LicenseService.userInformation = b.GetUserValidity(GetSettings("BrCode"))

                    SetSettings("BrName", info.FranchiseName)
                    SetSettings("ValidFrom", info.ValidFrom)
                    SetSettings("ValidTo", info.ValidTo)

                    SetSettings("ServerDate", b.GetServerDate)
                    SetSettings("LastDateUpdate", Today.Date)


                    If Convert.ToDateTime(GetSettings("ServerDate")) > Convert.ToDateTime(GetSettings("ValidTo")) Then
                        MsgBox("Your software validity period is lapsed. Please contact Administrator for more assistance.")
                        GoTo a
                    End If

                Catch ex As Exception

                    If (Today.Date - Convert.ToDateTime(GetSettings("LastDateUpdate"))).TotalDays > 30 Then
                        MsgBox("You have not gone online since last 60 days. You have to go online to use this Software.")
                        GoTo a

                    ElseIf Today.Date > Convert.ToDateTime(GetSettings("ValidTo")) Then
                        MsgBox("Your software validity period is lapsed. Please contact Administrator for more assistance.")
                        GoTo a
                    End If

                End Try


            Else
                MsgBox("Invalid user and/or Password, Login failed.", MsgBoxStyle.Critical, "Login")
            End If


            general.Load()

            If Environment.GetCommandLineArgs.Length = 1 Then
                frmCustomer.Show()
                Me.Close()
            Else
                Try
                    Me.TopMost = True

                    FilePath = Environment.GetCommandLineArgs(1)
                    TextBox1.Text = FilePath

                    tempPath = FilePath.Substring(0, FilePath.LastIndexOf(".szf"))
                    TextBox2.Text = tempPath

                    BackgroundWorker1.RunWorkerAsync()
                Catch ex As Exception

                    MessageBox.Show(ex.Message)

                    Me.Close()
                End Try
            End If


        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message, MsgBoxStyle.Critical, "Login")
        End Try
a:
        Me.Cursor = Cursors.Default
        Me.ResumeLayout()

    End Sub

    Private Sub BackgroundWorker1_DoWork(ByVal sender As System.Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker1.DoWork

        Dim tempString As String = FilePath.Substring(FilePath.LastIndexOf("\") + 1)
        Dim BrCode As String = tempString.Substring(0, tempString.LastIndexOf("_"))
        BrCode = BrCode.Substring(0, BrCode.LastIndexOf("_"))

        Try
            BrCode = BrCode.Substring(0, BrCode.LastIndexOf("_"))
        Catch ex As Exception

        End Try


        Dim brDt As DataTable = general.GetDataTable("SELECT FRcode FROM tblFrList WHERE FRcode='" + BrCode + "'")

        If brDt.Rows.Count = 0 Then
            brDt = general.GetDataTable("SELECT Count(FRcode) FROM tblFrList")
            If Convert.ToInt32(brDt.Rows(0)(0).ToString) < 50 Then
                general.WriteData("INSERT INTO tblFrList(FrCode,AddedDate,Extracted) VALUES('" + BrCode + "','" + Now.ToShortDateString() + "',1)") ',ModifiedDate
            Else
                MsgBox("Warning, you have already attached 10 franchises. You can not attach more than 10 franchises with this License of Admin. Please contact Softultima for more assistance.", MsgBoxStyle.Critical, "Can not attach more franchises")
                Exit Sub
            End If
        End If

        Try
            Using zip As ZipFile = ZipFile.Read(FilePath)
                zip.Encryption = EncryptionAlgorithm.WinZipAes256
                zip.Password = GetSettings("EncryptKey").ToString
                zip.ExtractAll(tempPath, Ionic.Zip.ExtractExistingFileAction.OverwriteSilently)
                zip.Dispose()
            End Using

            Dim profiles() As String = IO.Directory.GetFiles(tempPath, "*.xdf")

            For Each Str As String In profiles
                Dim ds As New DataSet
                ds.ReadXml(Str, XmlReadMode.Auto)

                For Each dt As DataTable In ds.Tables
                    Dim dt2 As DataTable = general.GetDataTable("SELECT CustCode FROM tblCustomer WHERE CustCode='" + dt.Rows(0)("CustCode").ToString + "'")
                    Dim query As String

                    If dt2.Rows.Count > 0 Then
                        If dt2.Rows(0)("CustCode").ToString.Equals(dt.Rows(0)("CustCode").ToString) Then
                            query = "UPDATE tblCustomer SET sName='" + dt.Rows(0)("sName").ToString + "', sParentName='" + dt.Rows(0)("sParentName").ToString + "', sLastName='" + dt.Rows(0)("sLastName").ToString + "', sGender='" + dt.Rows(0)("sGender").ToString + "', sContact='" + dt.Rows(0)("sContact").ToString + "', sAge='" + dt.Rows(0)("sAge").ToString + "', sAddress='" + dt.Rows(0)("sAddress").ToString + "', sCity='" + dt.Rows(0)("sCity").ToString + "', sState='" + dt.Rows(0)("sState").ToString + "', sEmail='" + dt.Rows(0)("sEmail").ToString + "', sPracCode='" + dt.Rows(0)("sPracCode").ToString + "', sPracName='" + dt.Rows(0)("sPracName").ToString + "', sPCE='" + dt.Rows(0)("sPCE").ToString + "', dtCreated='" + dt.Rows(0)("dtCreated").ToString + "', LATD='0', RATD='0', dtReceived='" + Now.Date.ToShortDateString + "', dtReported='', isReported=0 ) WHERE CustCode='" + dt.Rows(0)("CustCode").ToString + "'"

                        End If
                    Else
                        query = "INSERT INTO tblCustomer(CustCode, sName, sParentName, sLastName, sGender, sContact, sAge, sAddress, sCity, sState, sEmail, sPracCode, sPracName, sPCE, dtCreated, LATD, RATD, dtReceived, dtReported, isReported ) " +
                                "Values('" + dt.Rows(0)("CustCode").ToString + "', '" + dt.Rows(0)("sName").ToString + "', '" + dt.Rows(0)("sParentName").ToString + "', '" + dt.Rows(0)("sLastName").ToString + "', '" + dt.Rows(0)("sGender").ToString + "', '" + dt.Rows(0)("sContact").ToString + "', '" + dt.Rows(0)("sAge").ToString + "', '" + dt.Rows(0)("sAddress").ToString + "', '" + dt.Rows(0)("sCity").ToString + "', '" + dt.Rows(0)("sState").ToString + "', '" + dt.Rows(0)("sEmail").ToString + "', '" + dt.Rows(0)("sPracCode").ToString + "', '" + dt.Rows(0)("sPracName").ToString + "', '" + dt.Rows(0)("sPCE").ToString + "', '" + dt.Rows(0)("dtCreated").ToString + "', '0', '0', '" + Now.Date.ToShortDateString + "', '', 0) "
                    End If

                    general.WriteData(query)
                Next
                ds.Clear()
                ds.Dispose()
                ds = Nothing

                Try
                    IO.File.Delete(Str)
                Catch ex As Exception

                End Try

            Next

        Catch exc1 As Exception
            MessageBox.Show(String.Format("Exception while unzipping: {0}", exc1.Message))
        End Try

    End Sub

    Private Sub BackgroundWorker1_RunWorkerCompleted(ByVal sender As System.Object, ByVal e As System.ComponentModel.RunWorkerCompletedEventArgs) Handles BackgroundWorker1.RunWorkerCompleted
        Me.Close()
    End Sub

End Class

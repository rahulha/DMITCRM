﻿Imports System.Data

Public Class frmFranchise

    Private Sub frmCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If frmExtract.IsHandleCreated Then
            frmExtract.Close()
        End If

        Try
            Dim str As String = "SELECT FrCode as [Franchise Code], AddedDate as [Added date], ModifiedDate as [Modified Date] FROM tblFrList"

            Dim dt As DataTable = general.GetDataTable(str)

            Me.dgvCustomer.DataSource = Nothing
            Me.dgvCustomer.DataSource = dt

            If dt.Rows.Count > 0 Then
                Me.dgvCustomer.Rows(0).Cells(0).Selected = True

                Dim CustomerName As String = Me.dgvCustomer.Rows(0).Cells(1).Value
            End If

        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message)
        End Try

    End Sub

End Class
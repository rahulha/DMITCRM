﻿Imports System
Imports System.IO
Imports System.Text
Imports System.Security.Cryptography
Imports System.Runtime.InteropServices
Imports Ionic.Zip
Imports System.Data.OleDb
Imports System.Data

Public Module general

    Dim con As New OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + Application.StartupPath + "\AdminData.mdb; Persist Security Info=True;Jet OLEDB:Database Password=" & My.Settings.MasterKey & ";")
    Dim adp As New OleDbDataAdapter("SELECT * FROM tblCustomer", con)
    Dim dt As DataTable

    Public Sub Load()
        Try
            If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
                con.Open()
            End If

            dt = New DataTable

            adp.Fill(dt)
        Catch ex As Exception
        End Try
    End Sub

    Public Sub unLoad()
        Try
            con.Close()
        Catch ex As Exception
        End Try
    End Sub

    Public ReadOnly Property CustomerList As DataTable
        Get
            Return dt
        End Get
    End Property

    Public Function GetDataTable(ByVal SQLQuery As String) As DataTable
        If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
            con.Open()
        End If

        Dim adp As New OleDbDataAdapter(SQLQuery, con)
        Dim dt As New DataTable()

        Try
            adp.Fill(dt)
        Catch ex As Exception
        End Try


        Return dt
    End Function

    Public Function WriteData(ByVal SQLQuery As String) As Boolean
        Dim cmd As New OleDbCommand(SQLQuery, con)

        If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
            con.Open()
        End If

        Try
            cmd.ExecuteNonQuery()
            Return True
        Catch ex As Exception
            Throw ex
        End Try
    End Function

#Region "Settings Manager"

    Private hSettings As Hashtable

    Public Function LoadSettings() As Boolean
        hSettings = New Hashtable

        Dim adp As New OleDbDataAdapter("SELECT * FROM tblSettings", con)
        Dim dtSettings As New DataTable

        If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
            con.Open()
        End If

        adp.Fill(dtSettings)

        For Each dr As DataRow In dtSettings.Rows
            Try
                hSettings.Add(dr("Key").ToString().ToUpper, dr("Value"))
            Catch ex As Exception
                'WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + dr("key").ToString())
            End Try
        Next

        Return True

    End Function

    Public Function GetSettings(ByVal Key As String) As Object
        Try
            Key = Key.ToUpper
            If hSettings.ContainsKey(Key) Then
                Return hSettings(Key)
            Else

                Return Nothing
            End If
        Catch ex As Exception
            'WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + Key)
            Return Nothing
        End Try

    End Function

    Public Function SetSettings(ByVal Key As String, ByVal Value As Object) As Boolean
        Key = Key.ToUpper

        If hSettings.ContainsKey(Key) Then
            hSettings(Key) = Value

            Dim cmd As New OleDbCommand("UPDATE tblSettings SET [Value]=@Value WHERE [Key]='" + Key + "'", con)
            cmd.Parameters.AddWithValue("@Value", Value)

            If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
                con.Open()
            End If

            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                'WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + Key)
            End Try

            Return True
        Else
            hSettings.Add(Key, Value)

            Dim cmd As New OleDbCommand("INSERT INTO tblSettings Values('" + Key + "',@Value)", con)
            cmd.Parameters.AddWithValue("@Value", Value)

            If con.State = ConnectionState.Closed Or con.State = ConnectionState.Broken Then
                con.Open()
            End If

            Try
                cmd.ExecuteNonQuery()
            Catch ex As Exception
                ' WriteLog("General : Error : " + ex.Message + "; Source:" + ex.Source + "; StackTrace:" + ex.StackTrace + "; HelpLink:" + ex.HelpLink + "; Data:" + Key)
            End Try

            Return True
        End If

    End Function

#End Region

End Module

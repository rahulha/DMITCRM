﻿Imports System.Data

Public Class frmCustomer

    Private Sub frmCustomer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        BindData("", "", "")
        If frmExtract.IsHandleCreated Then
            frmExtract.Close()
        End If
    End Sub

    Private Sub BindData(ByVal Name As String, ByVal Middle As String, ByVal Last As String)

        Try

            Dim str As String = "SELECT CustCode as [Customer Code], sName as [First Name], sParentName as [Middle Name], sLastName as [Last Name], sGender as [Gender], sContact as [Contact], sEmail as [Email],sCity as [City], dtCreated as [Created date] FROM tblCustomer "

            Dim condition As String

            If Not String.IsNullOrEmpty(Name) Or Not String.IsNullOrEmpty(Middle) Or Not String.IsNullOrEmpty(Last) Then str &= " WHERE "

            If Not String.IsNullOrEmpty(Name) Then condition = " (((tblCustomer.sName) Like '" & Name & "%'))"

            If Not String.IsNullOrEmpty(Middle) Then
                If Not String.IsNullOrEmpty(condition) Then
                    condition &= " AND "
                End If
                condition &= " (((tblCustomer.sLastName) Like '" & Middle & "%'))"
            End If

            If Not String.IsNullOrEmpty(Last) Then
                If Not String.IsNullOrEmpty(condition) Then
                    condition &= " AND "
                End If
                condition &= " (((tblCustomer.sCity) Like '" & Last & "%'))"
            End If

            str &= condition
            Dim dt As DataTable = general.GetDataTable(str)

            Me.dgvCustomer.DataSource = Nothing
            Me.dgvCustomer.DataSource = dt

            If dt.Rows.Count > 0 Then
                Me.dgvCustomer.Rows(0).Cells(0).Selected = True

                Dim CustomerName As String = Me.dgvCustomer.Rows(0).Cells(1).Value
            End If

        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message)
        End Try
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        BindData(TextBox1.Text, TextBox2.Text, TextBox3.Text)
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        BindData(TextBox1.Text, TextBox2.Text, TextBox3.Text)
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged
        BindData(TextBox1.Text, TextBox2.Text, TextBox3.Text)
    End Sub

    Private Sub button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles button3.Click
        If Me.dgvCustomer.SelectedRows.Count > 0 Then

            For Each Rw As DataGridViewRow In Me.dgvCustomer.SelectedRows
                Dim customerID As String = Rw.Cells(0).Value

                Dim dr() As DataRow = general.CustomerList.Select("CustCode='" & customerID & "'")

                Me.Cursor = Cursors.WaitCursor
                Me.SuspendLayout()

                Dim f As New dlgCustomerDetails(dr(0), customerID)
                Me.ResumeLayout()
                Me.Cursor = Cursors.Default

                If f.ShowDialog = DialogResult.OK Then
                    f.Dispose()
                    f = Nothing

                    BindData(TextBox1.Text, TextBox2.Text, TextBox3.Text)

                    general.Load()
                End If
            Next
        End If
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        'Delete
        Try
            If Me.dgvCustomer.SelectedRows.Count > 0 Then

                For Each Rw As DataGridViewRow In Me.dgvCustomer.SelectedRows
                    Dim customerID As String = Rw.Cells(0).Value

                    Dim CustomerName As String = "Customet Code: " & Rw.Cells(0).Value & Environment.NewLine & "Customer Name: " & Rw.Cells(1).Value & " " & Rw.Cells(3).Value

                    If MsgBox("Are you sure you want to delete all details of selected customer?" & Environment.NewLine & CustomerName, MsgBoxStyle.YesNo, "Delete Customer") = MsgBoxResult.Yes Then

                        If general.WriteData("DELETE FROM tblCustomer WHERE CustCode='" & Rw.Cells(0).Value & "'") Then
                            Dim pathname As String = Application.StartupPath & "\CustData\" & customerID & ".szf"
                            If IO.File.Exists(pathname) Then
                                IO.File.Delete(pathname)
                            End If

                            general.Load()
                            BindData(TextBox1.Text, TextBox2.Text, TextBox3.Text)
                        Else
                            MsgBox("Some error occured while deleteing the customer. Please Contact developer for assistance.")
                        End If
                    End If
                Next

            End If
        Catch ex As Exception
            MsgBox("Error ocurred: " & ex.Message)
        End Try
    End Sub

    Private Sub btnFrList_Click(sender As System.Object, e As System.EventArgs) Handles btnFrList.Click
        frmFranchise.Show()
    End Sub
End Class